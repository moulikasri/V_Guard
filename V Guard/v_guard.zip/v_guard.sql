-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jul 05, 2022 at 04:48 PM
-- Server version: 5.7.36
-- PHP Version: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `v_guard`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(1, 'Neelesh', '12345');

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

DROP TABLE IF EXISTS `department`;
CREATE TABLE IF NOT EXISTS `department` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`id`, `username`, `password`) VALUES
(13, 'Neelesh', '111');

-- --------------------------------------------------------

--
-- Table structure for table `diesel_comsumption`
--

DROP TABLE IF EXISTS `diesel_comsumption`;
CREATE TABLE IF NOT EXISTS `diesel_comsumption` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `DG_UNITS_in_KW` varchar(100) NOT NULL,
  `TOTAL_DIESEL_CONSUMPTION` varchar(200) NOT NULL,
  `Conversion_Factor` varchar(20) DEFAULT NULL,
  `CO2_Emission_in_Kg` varchar(200) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`TOTAL_DIESEL_CONSUMPTION`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `emission_15`
--

DROP TABLE IF EXISTS `emission_15`;
CREATE TABLE IF NOT EXISTS `emission_15` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `DG_UNITS_in_KW` varchar(100) NOT NULL,
  `TOTAL_DIESEL_CONSUMPTION` varchar(200) NOT NULL,
  `Conversion_Factor` varchar(20) DEFAULT NULL,
  `CO2_Emission_in_Kg` varchar(200) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`TOTAL_DIESEL_CONSUMPTION`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `emission_380`
--

DROP TABLE IF EXISTS `emission_380`;
CREATE TABLE IF NOT EXISTS `emission_380` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `DG_UNITS_in_KW` varchar(100) NOT NULL,
  `TOTAL_DIESEL_CONSUMPTION` varchar(200) NOT NULL,
  `Conversion_Factor` varchar(20) DEFAULT NULL,
  `CO2_Emission_in_Kg` varchar(200) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`TOTAL_DIESEL_CONSUMPTION`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `options`
--

DROP TABLE IF EXISTS `options`;
CREATE TABLE IF NOT EXISTS `options` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `dept` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `options`
--

INSERT INTO `options` (`id`, `dept`) VALUES
(1, 'Dept1'),
(2, 'Dept2'),
(3, 'Dept3');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
